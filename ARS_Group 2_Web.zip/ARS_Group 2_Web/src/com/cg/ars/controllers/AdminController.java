package com.cg.ars.controllers;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ars.dtos.BookingInfoBean;
import com.cg.ars.dtos.FlightInfoBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.services.AdminService;
import com.cg.ars.services.ValidateService;

@Controller
public class AdminController {

	@Resource
	ValidateService validateService;
	@Resource
	AdminService adminService;
	
	@RequestMapping("/getAdminHomePage.do")
	public ModelAndView getHomePage(){
		ModelAndView mAndV = new ModelAndView("AdminInterface");
		return mAndV;
	}
	
	//Redirecting to the getNewFlightEntryPage
		@RequestMapping("/getNewFlightEntryPage.do")
		public ModelAndView getNewFlightEntryPage() throws AirlineException{
		
			ModelAndView mAndV = new ModelAndView();
			LocalDate date = LocalDate.now();
			mAndV.addObject("today", date);
			mAndV.setViewName("NewFlightEntryPage");
			return mAndV;
		}
		
		//Accepting the details of the new flight and processing
		@RequestMapping(value="/submitFlightDetails.do",method=RequestMethod.POST)
		public ModelAndView submitFlightDetails(@RequestParam("flightNo") int flightNo,
												@RequestParam("airline") String airline,
												@RequestParam("depCity") String depCity,
												@RequestParam("arrCity") String arrCity,
												@RequestParam("depDate") String strDepDate,
												@RequestParam("arrDate") String strArrDate,
												@RequestParam("depTime") String depTime,
												@RequestParam("arrTime") String arrTime,
												@RequestParam("firstSeats") int firstSeats,
												@RequestParam("firstSeatFare") float firstSeatFare,
												@RequestParam("bussSeats") int bussSeats,
												@RequestParam("bussSeatFare") float bussSeatFare
												)throws AirlineException
			{
			ModelAndView mAndV =new ModelAndView();
			
			boolean isFlightNoExisting = validateService.validateFlightNo(flightNo);
			System.out.println(isFlightNoExisting);
			
			//checking flight no is unique
			if(!isFlightNoExisting)
		   {
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat timeFormat = new SimpleDateFormat("hh:mm");
			Date depDate = null;
			Date arrDate = null;
			Date depTime1 = null;
			Date arrTime1 = null;
			
			try {
				depDate = format.parse(strDepDate);
				arrDate = format.parse(strArrDate);
				depTime1 = timeFormat.parse(depTime);
				arrTime1 = timeFormat.parse(arrTime);
			} catch (ParseException e) {
				
				throw new AirlineException("Problem in reading date", e);
			}
			
			
				if(depDate.compareTo(arrDate)<=0 && depTime1.compareTo(arrTime1)<0){
					
					FlightInfoBean flightBean=new FlightInfoBean();
					
					flightBean.setFlightNo(flightNo);
					flightBean.setAirline(airline);
					flightBean.setDepCity(depCity);
					flightBean.setArrCity(arrCity);
					flightBean.setArrDate(arrDate);
					flightBean.setDepDate(depDate);
					flightBean.setDepTime(depTime);
					flightBean.setArrTime(arrTime);
					flightBean.setFirstSeats(firstSeats);
					flightBean.setFirstSeatsAvailable(firstSeats);
					flightBean.setFirstSeatFare(firstSeatFare);
					flightBean.setBussSeats(bussSeats);
					flightBean.setBussSeatsAvailable(bussSeats);
					flightBean.setBussSeatFare(bussSeatFare);
					
					
					//If the flight is created successfully, then redirecting to the success page 
					adminService.createNewFlight(flightBean);
					mAndV.setViewName("SuccessCreateFlightPage");
					FlightInfoBean flightBean1 = adminService.viewFlightDetailsOnId(flightNo);
					mAndV.addObject("flightBean", flightBean1);
					}
					
					//If flight no is not unique, then redirecting to the same page to try again..
					else{
						String message = "Please ensure Start Date is less than or equal to End Date or Start Time is less than End Time";
						
						mAndV.addObject("message", message);
						LocalDate date = LocalDate.now();
						mAndV.addObject("today", date);
						mAndV.setViewName("NewFlightEntryPage");
					}
			} else{
				String message = "Flight with flight no " +flightNo+ " already exists. Please enter a unique flight no.";
				mAndV.addObject("message", message);
				LocalDate date = LocalDate.now();
				mAndV.addObject("today", date);
				mAndV.setViewName("NewFlightEntryPage");
			}
			
			return mAndV;
		}
		
		
		
		
		
		
	//**********************************************************
	
	//Redirecting to the updateFlight Page
		@RequestMapping("/getFlightNoForUpdate.do")
		public ModelAndView getFlightNoForUpdate() throws AirlineException{
			ModelAndView mAndV = new ModelAndView();
			String flag = "getFlightNo";
			mAndV.addObject("flag", flag);
			mAndV.setViewName("UpdateFlightPage");
			return mAndV;
		}
		
		@RequestMapping(value="/getUpdateFlightInfo.do", method=RequestMethod.POST)
		public ModelAndView getUpdateInfoPage(@RequestParam("flightNo") int flightNo
				) throws AirlineException{
			
			ModelAndView mAndV = new ModelAndView();
			
			boolean isFlightNoValid = validateService.validateFlightNo(flightNo);
			
			if(isFlightNoValid){
				FlightInfoBean flightBean = adminService.viewFlightDetailsOnId(flightNo);
				
				//check whether bookings are made for this flight or not
				ArrayList<BookingInfoBean> bookingList = adminService.viewBookingListOnFlightNo(flightNo);
				if(bookingList.isEmpty()){
					String flag = "No Booking";
					mAndV.addObject("flag", flag);
					LocalDate date = LocalDate.now();
					mAndV.addObject("today", date);
					mAndV.addObject("flightBean" , flightBean);
				} //booking list is empty
				else {
					String flag = "Has Booking";
					mAndV.addObject("flag", flag);
					LocalDate date = LocalDate.now();
					mAndV.addObject("today", date);
					String message = "Some Bookings are made on the flight " + flightNo;
					mAndV.addObject("message", message);
					mAndV.addObject("flightBean" , flightBean);
				} //booking list is not empty
			} 
			//valid flight no
			else {
				String message = "Sorry there is no flight with flight no: "+ flightNo;
				mAndV.addObject("message", message);
				String flag = "getFlightNo";
				mAndV.addObject("flag", flag);
			}
			
			mAndV.setViewName("UpdateFlightPage");
			return mAndV;
			
		}
		
		//Updating the flight details
		@RequestMapping(value="/updateFlightDetails.do",method=RequestMethod.POST)
		public ModelAndView updatingFlightDetails(@RequestParam("flightNo") int flightNo,
												@RequestParam("airline") String airline,
												@RequestParam("depCity") String depCity,
												@RequestParam("arrCity") String arrCity,
												@RequestParam("depDate") String strDepDate,
												@RequestParam("arrDate") String strArrDate,
												@RequestParam("depTime") String depTime,
												@RequestParam("arrTime") String arrTime,
												@RequestParam("firstSeats") int firstSeats,
												@RequestParam("firstSeatFare") float firstSeatFare,
												@RequestParam("bussSeats") int bussSeats,
												@RequestParam("bussSeatFare") float bussSeatFare) throws AirlineException
		{
			ModelAndView mAndV =new ModelAndView();
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat timeFormat = new SimpleDateFormat("hh:mm");
			Date depDate = null;
			Date arrDate = null;
			Date depTime1 = null;
			Date arrTime1 = null;
			
			try {
				depDate = format.parse(strDepDate);
				arrDate = format.parse(strArrDate);
				depTime1 = timeFormat.parse(depTime);
				arrTime1 = timeFormat.parse(arrTime);
			} catch (ParseException e) {
				
				throw new AirlineException("Problem in reading date", e);
			}
			
			if(!(depDate.compareTo(arrDate)<=0 && depTime1.compareTo(arrTime1)<0)){
				String message = "Please ensure Start Date is less than or equal to End Date or Start Time is less than End Time";
				mAndV.addObject("message", message);
				mAndV.setViewName("SuccessUpdateFlightPage");
				return mAndV;
			}
			
			
			
			FlightInfoBean flightBean=new FlightInfoBean();
			flightBean.setFlightNo(flightNo);
			flightBean.setAirline(airline);
			flightBean.setDepCity(depCity);
			flightBean.setArrCity(arrCity);
			flightBean.setArrDate(arrDate);
			flightBean.setDepDate(depDate);
			flightBean.setDepTime(depTime);
			flightBean.setArrTime(arrTime);
			flightBean.setFirstSeats(firstSeats);
			flightBean.setFirstSeatsAvailable(firstSeats);
			flightBean.setFirstSeatFare(firstSeatFare);
			flightBean.setBussSeats(bussSeats);
			flightBean.setBussSeatsAvailable(bussSeats);
			flightBean.setBussSeatFare(bussSeatFare);
			
			//If the flight is updated successfully, then redirecting to the success page 
			
				
				Boolean isFlightUpdated = adminService.updateFlightDetails(flightBean);
				
				if(isFlightUpdated){
					FlightInfoBean flightBean1 = adminService.viewFlightDetailsOnId(flightNo);
					mAndV.addObject("flightBean", flightBean1);
					
				} else{
					String message = "Some Problem while updating data";
				}
			
			mAndV.setViewName("SuccessUpdateFlightPage");
			return mAndV;
			
		}
		
		//Updating the flight details
		@RequestMapping(value="/updateFlightWithBooking.do",method=RequestMethod.POST)
		public ModelAndView updateFlightWithBooking(@RequestParam("flightNo") int flightNo,
												@RequestParam("airline") String airline,
												@RequestParam("depCity") String depCity,
												@RequestParam("arrCity") String arrCity,
												@RequestParam("depDate") String strDepDate,
												@RequestParam("arrDate") String strArrDate,
												@RequestParam("depTime") String depTime,
												@RequestParam("arrTime") String arrTime,
												@RequestParam("firstSeats") int firstSeats,
												@RequestParam("firstSeatFare") float firstSeatFare,
												@RequestParam("bussSeats") int bussSeats,
												@RequestParam("bussSeatFare") float bussSeatFare) throws AirlineException
		{
			
ModelAndView mAndV =new ModelAndView();
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat timeFormat = new SimpleDateFormat("hh:mm");
			Date depDate = null;
			Date arrDate = null;
			Date depTime1 = null;
			Date arrTime1 = null;
			
			try {
				depDate = format.parse(strDepDate);
				arrDate = format.parse(strArrDate);
				depTime1 = timeFormat.parse(depTime);
				arrTime1 = timeFormat.parse(arrTime);
			} catch (ParseException e) {
				
				throw new AirlineException("Problem in reading date", e);
			}
			
			if((depTime1.compareTo(arrTime1)>=0)){
				String message = "Please ensure Start Time is less than or equal to End Time";
				mAndV.addObject("message", message);
				mAndV.setViewName("SuccessUpdateFlightPage");
				return mAndV;
			}
		
			FlightInfoBean flightBean=new FlightInfoBean();
			flightBean.setFlightNo(flightNo);
			flightBean.setAirline(airline);
			flightBean.setDepCity(depCity);
			flightBean.setArrCity(arrCity);
			flightBean.setArrDate(arrDate);
			flightBean.setDepDate(depDate);
			flightBean.setDepTime(depTime);
			flightBean.setArrTime(arrTime);
			flightBean.setFirstSeats(firstSeats);
			flightBean.setFirstSeatsAvailable(firstSeats);
			flightBean.setFirstSeatFare(firstSeatFare);
			flightBean.setBussSeats(bussSeats);
			flightBean.setBussSeatsAvailable(bussSeats);
			flightBean.setBussSeatFare(bussSeatFare);
			
			//If the flight is updated successfully, then redirecting to the success page 
			
				
				boolean isFlightUpdated = adminService.updateFlightDetails(flightBean);
			
				
				
				if(isFlightUpdated){
					
					FlightInfoBean flightBean1 = adminService.viewFlightDetailsOnId(flightNo);
					boolean isBookingUpdated = adminService.updateBookingDetailsOnFlightNo(flightNo);
					mAndV.addObject("flightBean", flightBean1);
					
				} else{
					String message = "Some Problem while updating data";
				}
			
			mAndV.setViewName("SuccessUpdateFlightPage");
			return mAndV;
			
		}
		
//*************************************************************************
		//Redirecting to the removeFlight Page
		@RequestMapping("/getRemoveFlightPage.do")
		public ModelAndView getRemoveFlightPage() throws AirlineException{
			ModelAndView mAndView = new ModelAndView();
			mAndView.setViewName("RemoveFlightPage");
			return mAndView;
		}
		
		//Removing the flight details
		@RequestMapping(value="/flightDetailsToRemove.do",method=RequestMethod.POST)
		public ModelAndView getFlightDetailsToRemove(@RequestParam("flightNo") int flightNo) throws AirlineException{
			
			ModelAndView mAndView = new ModelAndView();
			
			boolean isFlightNoExisting=false;
			
			isFlightNoExisting=validateService.validateFlightNo(flightNo);
			
			if(isFlightNoExisting){
				FlightInfoBean flightBean = adminService.viewFlightDetailsOnId(flightNo);
				mAndView.addObject("flightBean" , flightBean);
				
			}
			//If there is a failure in the removal of the flight, then redirecting to the same page to try again..
			else if(!isFlightNoExisting){
				String message = "No flight exists on given flight No " + flightNo;
				mAndView.addObject("message", message);
			}
			mAndView.setViewName("RemoveFlightPage");
			return mAndView;
		}
		
		@RequestMapping(value="/removeFlight.do",method=RequestMethod.POST)
		public ModelAndView removeFlight(@RequestParam("flightNo") int flightNo) throws AirlineException{
			
			ModelAndView mAndView = new ModelAndView();
			
			boolean isFlightRemoved=false;
			String message = null;
			
			ArrayList<BookingInfoBean> bookingList = adminService.viewBookingListOnFlightNo(flightNo);
			
			if(bookingList.isEmpty()){
				isFlightRemoved = adminService.removeFlight(flightNo);
				if(isFlightRemoved){
					message = "Flight No " + flightNo + " removed successfully.";
				} else{
					message = "Problem in removing flight " + flightNo;
				}
				
				mAndView.addObject("message", message);
 			} else{
 				message = "Sorry!!!! This flight " + flightNo + " has some bookings. Can't remove the flight.";
 				mAndView.addObject("message", message);
 			}
			
			mAndView.setViewName("RemoveFlightPage");
			return mAndView;
		}
		
//**************************************************************
		
		@RequestMapping("/getBookingDetailsPage.do")
		public ModelAndView getBookingDetailsPage() throws AirlineException{
			ModelAndView mAndView = new ModelAndView();
			mAndView.setViewName("FlightBookingDetailsPage");
			return mAndView;
		}
		
		@RequestMapping(value="/FlightBookingDetails.do",method=RequestMethod.POST)
		public ModelAndView getFlightBookingDetails(@RequestParam("flightNo") int flightNo) throws AirlineException{
			
			ModelAndView mAndView = new ModelAndView();
			
			boolean isFlightNoExisting=false;
			
			isFlightNoExisting=validateService.validateFlightNo(flightNo);
			
			if(isFlightNoExisting){
				
				ArrayList<BookingInfoBean> bookingList = adminService.viewBookingListOnFlightNo(flightNo);
				if(bookingList.isEmpty()){
					String message = "No bookings made on given flight No " + flightNo;
					mAndView.addObject("message", message); 
				}else{
					
					FlightInfoBean flightBean = adminService.viewFlightDetailsOnId(flightNo);
					mAndView.addObject("flightBean" , flightBean);
					mAndView.addObject("bookingList" , bookingList);
				}
			}
			
			else if(!isFlightNoExisting){
				String message = "No flight exists on given flight No " + flightNo;
				mAndView.addObject("message", message);
			}
			mAndView.setViewName("FlightBookingDetailsPage");
			return mAndView;
		}
		
		
}
