
i.	Users
===============================================================================

insert into users values('Shubham','Goel','shubh123', 'qwerty22', 'admin');
insert into users values('Ashutosh','Gupta','ashu333', 'zxcv12', 'customer');
insert into users values('Amulya','Bhavana','ammu678', 'user444', 'executive');
insert into users values('Ankita','Suman','anki77', 'mac786', 'customer');
insert into users values('Arindam','Raj','arind11', 'qwerty92', 'executive');
insert into users values('Shubham','Kumar','shubh666', 'qwert321', 'customer');
insert into users values('Mayank','Tewatia','mayank3', 'qwe678', 'executive');
insert into users values('Ommi','Bhavana','ommi9', 'qwergh2', 'customer');
insert into users values('Anju','Agnes','anju1', 'qwe1234', 'customer');
insert into users values('Archana','Tirkey','arch123', 'sys212', 'customer');
insert into users values('Tannu','Shree','tannu99', 'roni143', 'admin');
insert into users values('Rajat','Sehra','rajat7', 'kavi77', 'executive');
insert into users values('Sanket','Niraspatil','sanket44', 'tree345', 'admin');
insert into users values('Sushmita','Singh','shubbo8', 'reddy1', 'customer');
insert into users values('Aditi','Sharma','adi65', 'ksh', 'executive');
insert into users values('Atul','Marmit','atul3', 'kamali81', 'customer');
insert into users values('Pankaj','Saraswat','pankaj01', 'sania68', 'customer');
insert into users values('Avinash','Saran','avi', 'ksac55', 'executive');
insert into users values('Mahendra','Bisht','mac4', 'bitc7', 'admin');
insert into users values('Akanksha','Suman','akku5', 'abhi1', 'customer');


ii.	Airport:
===============================================================================

insert into airport values('Indira Gandhi International Airport', 'DEL', 'Delhi');
insert into airport values('Chhatrpati Shivaji International Airport', 'BOM', 'Mumbai');
insert into airport values('Jay Prakash Narayan International Airport', 'PAT', 'Patna');
insert into airport values('Kempegowda International Airport', 'BLR', 'Bangalore');
insert into airport values('Pune International Airport', 'PNQ', 'Pune');
insert into airport values('Rajiv Gandhi International Airport', 'HYD', 'Hyderabad');
insert into airport values('Chennai International Airport', 'MAA', 'Chennai');
insert into airport values('Sri Guru Ram Dass Jee International Airport', 'ATQ', 'Amritsar');
insert into airport values('Biju Patnaik International Airport', 'BBI', 'Bhubaneswar');
insert into airport values('Netaji Subhas Chandra Bose International Airport', 'CCU', 'Kolkata');
insert into airport values('Cochin International Airport', 'COK', 'Cochin');
insert into airport values('Sardar Vallabhbhai Patel International Airport', 'AMD', 'Ahmedabad');
insert into airport values('Goa International Airport', 'GOI', 'Dabolim');
insert into airport values('Coimbatore International Airport', 'CJB', 'Coimbatore');
insert into airport values('Lal Bahadur Shastri International Airport', 'VNS', 'Varanasi');
insert into airport values('Tiruchirapalli International Airport', 'TRZ', 'Tiruchirapalli');


iii.	FlightInformation:
===============================================================================

insert into flightInfo values(1111,'SpiceJet','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','20:55','23:30',40,40,6000,35,35,10000 );
insert into flightInfo values(1114,'Go Air','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','18:20','21:45',45,45,5500,40,40,12000 );
insert into flightInfo values(1115,'JetLite','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','10:30','12:55',45,45,7000,30,30,12000);
insert into flightInfo values(3456,'IndiGO','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','06:55','09:30',35,35,6500,40,40,9000);
insert into flightInfo values(7658,'Vistara','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','11:35','14:30',50,50,6000,45,45,11000 );
insert into flightInfo values(2398,'TrueJet','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','20:50','23:25',40,40,5500,25,25,10000);
insert into flightInfo values(9700,'Air India','Delhi','Mumbai','26-OCT-2017','26-OCT-2017','20:55','23:30',40,40,7000,30,30,10500 );

insert into flightInfo values(1254,'IndiGO','Patna','Chennai','2-NOV-2017','2-NOV-2017','21:15','23:35',40,40,5000,30,30,10000);
insert into flightInfo values(9874,'JetLite','Patna','Chennai','2-NOV-2017','2-NOV-2017','22:15','23:57',40,40,3000,30,30,11000);
insert into flightInfo values(4308,'Vistara','Patna','Chennai','2-NOV-2017','2-NOV-2017','10:15','13:35',40,40,4000,30,30,12000);
insert into flightInfo values(7689,'TrueJet','Patna','Chennai','2-NOV-2017','2-NOV-2017','02:15','05:25',40,40,4500,30,30,13000);
insert into flightInfo values(8966,'Air India Airlines','Patna','Chennai','2-NOV-2017','2-NOV-2017','08:15','10:35',40,40,3600,30,30,10500);
insert into flightInfo values(1299,'SpiceJet','Patna','Chennai','2-NOV-2017','2-NOV-2017','12:15','14:35',40,40,4200,30,30,10700);
insert into flightInfo values(8872,'Kingfisher','Patna','Chennai','2-NOV-2017','2-NOV-2017','16:15','19:35',40,40,3100,30,30,9000);

insert into flightInfo values(1333,'Go Air','Delhi','Patna','26-OCT-2017','26-OCT-2017','18:15','20:30',45,45,5500,40,40,12000);
insert into flightInfo values(3454,'IndiGO','Delhi','Patna','26-OCT-2017','26-OCT-2017','18:15','20:30',45,45,5575,40,40,10000);
insert into flightInfo values(9995,'Vistara','Delhi','Patna','26-OCT-2017','26-OCT-2017','18:15','20:30',45,45,4000,40,40,12080);
insert into flightInfo values(6663,'TrueJet','Delhi','Patna','26-OCT-2017','26-OCT-2017','18:15','20:30',45,45,3500,40,40,9000);
insert into flightInfo values(6664,'Kingfisher','Delhi','Patna','26-OCT-2017','26-OCT-2017','18:15','20:30',45,45,4400,40,40,9700);
insert into flightInfo values(6662,'Air India','Delhi','Patna','26-OCT-2017','26-OCT-2017','18:15','20:30',45,45,2600,40,40,11000);

insert into flightInfo values(1444,'IndiGO','Ahmedabad','Mumbai','28-OCT-2017','28-OCT-2017','20:25','22:30',40,40,6000,35,35,11000);
insert into flightInfo values(4441,'TrueJet','Ahmedabad','Mumbai','28-OCT-2017','28-OCT-2017','21:25','23:30',40,40,4000,35,35,9000);
insert into flightInfo values(2221,'SpiceJet','Ahmedabad','Mumbai','28-OCT-2017','28-OCT-2017','10:25','12:30',40,40,3000,35,35,8080);
insert into flightInfo values(9292,'Vistara','Ahmedabad','Mumbai','28-OCT-2017','28-OCT-2017','11:45','13:40',40,40,2000,35,35,9700);


insert into flightInfo values(1555,'SpiceJet','Amritsar','Kolkata','30-OCT-2017','30-OCT-2017','21:25','22:30',45,45,2500,30,30,8000);
insert into flightInfo values(9012,'Go Air','Amritsar','Kolkata','30-OCT-2017','30-OCT-2017','10:25','12:30',45,45,2400,30,30,9000);
insert into flightInfo values(3280,'IndiGO','Amritsar','Kolkata','30-OCT-2017','30-OCT-2017','04:40','06:45',45,45,1800,30,30,10000);
insert into flightInfo values(4389,'Vistara','Amritsar','Kolkata','30-OCT-2017','30-OCT-2017','01:25','03:40',45,45,3750,30,30,11000);
insert into flightInfo values(8192,'TrueJet','Amritsar','Kolkata','30-OCT-2017','30-OCT-2017','20:25','21:30',45,45,2600,30,30,9500);

insert into flightInfo values(6598,'IndiGO','Delhi','Coimbatore','24-OCT-2017','24-OCT-2017','19:00','20:30',50,19,4045,30,30,12000);
insert into flightInfo values(1666,'SpiceJet','Delhi','Coimbatore','24-OCT-2017','24-OCT-2017','20:05','21:35',50,19,3000,30,30,11000);
insert into flightInfo values(8787,'Kingfisher','Delhi','Coimbatore','24-OCT-2017','24-OCT-2017','11:00','12:15',50,19,2000,30,30,11500);


insert into flightInfo values(1777,'IndiGO','Amritsar','Mumbai','29-OCT-2017','29-OCT-2017','21:10','22:30',45,45,3500,30,30,12000);
insert into flightInfo values(1770,'SpiceJet','Amritsar','Mumbai','29-OCT-2017','29-OCT-2017','11:10','12:30',45,45,4200,30,30,9000);
insert into flightInfo values(2377,'Kingfisher','Amritsar','Mumbai','29-OCT-2017','29-OCT-2017','06:45','08:30',45,45,2800,30,30,9800);
insert into flightInfo values(2177,'Go Air','Amritsar','Mumbai','29-OCT-2017','29-OCT-2017','20:35','21:50',45,45,2200,30,30,11000);
insert into flightInfo values(1774,'TrueJet','Amritsar','Mumbai','29-OCT-2017','29-OCT-2017','09:30','11:05',45,45,6000,30,30,10000);

insert into flightInfo values(2777,'Go Air','Mumbai','Delhi','25-OCT-2017','25-OCT-2017','11:10','12:30',45,45,7200,30,30,12500);
insert into flightInfo values(3777,'SpiceJet','Mumbai','Delhi','25-OCT-2017','25-OCT-2017','06:20','07:35',45,45,3400,30,30,11000);
insert into flightInfo values(4777,'Vistara','Mumbai','Delhi','25-OCT-2017','25-OCT-2017','08:40','09:55',45,45,2800,30,30,13000);
insert into flightInfo values(5777,'TrueJet','Mumbai','Delhi','25-OCT-2017','25-OCT-2017','19:50','20:55',45,45,3890,30,30,12750);
insert into flightInfo values(6777,'Kingfisher','Mumbai','Delhi','25-OCT-2017','25-OCT-2017','21:10','23:30',45,45,2300,30,30,9600);

insert into flightInfo values(1888,'SpiceJet','Coimbatore','Mumbai','01-NOV-2017','01-NOV-2017','20:45','23:45',40,40,5500,25,25,11000);
insert into flightInfo values(1880,'Vistara','Coimbatore','Mumbai','01-NOV-2017','01-NOV-2017','10:40','12:40',40,40,5400,25,25,10075);
insert into flightInfo values(1886,'Air India','Coimbatore','Mumbai','01-NOV-2017','01-NOV-2017','04:05','05:12',40,40,5200,25,25,9700);
insert into flightInfo values(1887,'Kingfisher','Coimbatore','Mumbai','01-NOV-2017','01-NOV-2017','09:15','10:25',40,40,4500,25,25,9800);

insert into flightInfo values(1999,'SpiceJet','Tiruchirapalli','Mumbai','31-OCT-2017','31-OCT-2017','20:00','22:20',35,35,4000,30,30,12500);
insert into flightInfo values(1459,'IndiGO','Tiruchirapalli','Mumbai','31-OCT-2017','31-OCT-2017','21:00','23:20',35,35,4750,30,30,10075);
insert into flightInfo values(1569,'Vistara','Tiruchirapalli','Mumbai','31-OCT-2017','31-OCT-2017','12:00','13:30',35,35,3500,30,30,13000);
insert into flightInfo values(1679,'Kingfisher','Tiruchirapalli','Mumbai','31-OCT-2017','31-OCT-2017','20:45','22:55',35,35,2800,30,30,12500);
insert into flightInfo values(2129,'TrueJet','Tiruchirapalli','Mumbai','31-OCT-2017','31-OCT-2017','10:25','12:45',35,35,2950,30,30,9800);
insert into flightInfo values(3699,'Air India','Tiruchirapalli','Mumbai','31-OCT-2017','31-OCT-2017','11:10','13:50',35,35,3000,30,30,11500);

insert into flightInfo values(2233,'Go Air','Delhi','Dabolim','03-NOV-2017','03-NOV-2017','21:25','23:20',45,45,5100,30,30,11500);
insert into flightInfo values(2244,'TrueJet','Delhi','Dabolim','03-NOV-2017','03-NOV-2017','10:25','12:20',45,45,6200,30,30,9000);
insert into flightInfo values(2255,'IndiGO','Delhi','Dabolim','03-NOV-2017','03-NOV-2017','05:20','06:45',45,45,6500,30,30,9600);
insert into flightInfo values(2266,'Air India','Delhi','Dabolim','03-NOV-2017','03-NOV-2017','19:25','22:20',45,45,6570,30,30,10075);

insert into flightInfo values(3221,'SpiceJet','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','20:15','23:30',40,40,5000,30,30,12500);
insert into flightInfo values(4221,'Vistara','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','21:15','23:55',40,40,6500,30,30,12000);
insert into flightInfo values(2621,'TrueJet','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','10:25','12:30',40,40,5500,30,30,8500);
insert into flightInfo values(2291,'IndiGO','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','04:55','07:15',40,40,3500,30,30,9500);
insert into flightInfo values(2921,'Kingfisher','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','11:45','13:40',40,40,2600,30,30,12500);
insert into flightInfo values(2121,'Air India','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','09:25','12:35',40,40,1800,30,30,8000);
insert into flightInfo values(9221,'Go Air','Pune','Ahmedabad','04-NOV-2017','04-NOV-2017','19:40','21:50',40,40,2400,30,30,9570);


insert into flightInfo values(2311,'SpiceJet','Varanasi','Mumbai','23-OCT-2017','23-OCT-2017','20:55','23:30',35,35,6500,40,40,9000);
insert into flightInfo values(2211,'Vistara','Varanasi','Mumbai','23-OCT-2017','23-OCT-2017','19:55','22:40',35,35,5500,40,40,8000);
insert into flightInfo values(2241,'Kingfisher','Varanasi','Mumbai','23-OCT-2017','23-OCT-2017','10:40','12:55',35,35,4570,40,40,8500);

insert into flightInfo values(2111,'Go Air','Ahmedabad','Varanasi','05-NOV-2017','05-NOV-2017','18:30','21:30',45,45,6500,40,40,12000);
insert into flightInfo values(3111,'Air India','Ahmedabad','Varanasi','05-NOV-2017','05-NOV-2017','12:35','13:20',45,45,4500,40,40,11000);
insert into flightInfo values(2411,'IndiGO','Ahmedabad','Varanasi','05-NOV-2017','05-NOV-2017','09:10','10:15',45,45,5500,40,40,10000);
insert into flightInfo values(5111,'TrueJet','Ahmedabad','Varanasi','05-NOV-2017','05-NOV-2017','06:20','07:10',45,45,6000,40,40,9000);

insert into flightInfo values(2110,'Go Air','Mumbai','Patna','06-NOV-2017','06-NOV-2017','18:30','21:30',45,45,6500,40,40,12000);
insert into flightInfo values(2118,'IndiGO','Mumbai','Patna','07-NOV-2017','06-NOV-2017','18:30','21:30',45,45,4600,40,40,9600);
insert into flightInfo values(2116,'TrueJet','Mumbai','Patna','08-NOV-2017','06-NOV-2017','18:30','21:30',45,45,5500,40,40,9900);
insert into flightInfo values(2141,'Air India','Mumbai','Patna','06-NOV-2017','06-NOV-2017','8:30','11:30',45,45,5570,40,40,11000);

insert into flightInfo values(9116,'Go Air','Mumbai','Ahmedabad','07-NOV-2017','07-NOV-2017','18:30','21:30',45,45,5570,40,40,11000);
insert into flightInfo values(8116,'Vistara','Mumbai','Ahmedabad','07-NOV-2017','07-NOV-2017','19:30','22:30',45,45,5570,40,40,9600);
insert into flightInfo values(7116,'Kingfisher','Mumbai','Ahmedabad','07-NOV-2017','07-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);

insert into flightInfo values(6116,'SpiceJet','Mumbai','Ahmedabad','03-NOV-2017','03-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);
insert into flightInfo values(5116,'TrueJet','Mumbai','Varanasi','04-NOV-2017','04-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);
insert into flightInfo values(4116,'Kingfisher','Mumbai','Dabolim','06-NOV-2017','06-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);
insert into flightInfo values(2216,'Air India','Mumbai','Tiruchirapalli','07-NOV-2017','07-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);
insert into flightInfo values(2316,'Kingfisher','Mumbai','Kolkata','05-NOV-2017','05-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);
insert into flightInfo values(2416,'IndiGO','Mumbai','Chennai','07-NOV-2017','07-NOV-2017','10:30','13:15',45,45,5570,40,40,9900);

=======================================================================