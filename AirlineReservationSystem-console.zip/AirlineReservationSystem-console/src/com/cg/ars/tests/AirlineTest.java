package com.cg.ars.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ars.beans.BookingInfoBean;
import com.cg.ars.daos.BookingInfoDaoImpl;
import com.cg.ars.daos.FlightInfoDaoImpl;
import com.cg.ars.exceptions.AirlineException;

public class AirlineTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void insertTest() throws AirlineException {
		
		BookingInfoDaoImpl dao = new BookingInfoDaoImpl();
		BookingInfoBean bean = new BookingInfoBean();
		
		bean.setFlightNo(123);
		bean.setCustEmail("ashu@gmail.com");
		bean.setNoOfPassengers(5);
		bean.setClassType("FIRST");
		bean.setTotalFare(45000);
		bean.setCreditCardInfo("1234567891234560");
		bean.setSrcCity("Delhi");
		bean.setDestCity("Mumbai");
		
		int bookingId = dao.createNewBooking(bean);
		
		assertEquals(1022, bookingId);
		
		
	}
	
	/*@Test
	public void removeTest() throws AirlineException {
		
		BookingInfoDaoImpl dao = new BookingInfoDaoImpl();
		
		int bookingId = 1009;
		boolean check = dao.removeBookingOnId(bookingId);
		
		
		assertEquals(true, check);
		
		
	}*/
	
/*	@Test
	public void removeFlight() throws AirlineException {
		
		FlightInfoDaoImpl dao = new FlightInfoDaoImpl(); 
		
		int flightNo = 7777;
		boolean check = dao.removeFlight(flightNo);
		
		
		assertEquals(true, check);
		
		
	}*/

	/*@Test
	public void updateArrivalTime() throws AirlineException {
		
		FlightInfoDaoImpl dao = new FlightInfoDaoImpl(); 
		
		int flightNo = 1111;
		String arrTime = "06:30";
		boolean check = dao.updateArrTime(1111, arrTime);
		
		assertEquals(true, check);
		
		
	}*/

}
