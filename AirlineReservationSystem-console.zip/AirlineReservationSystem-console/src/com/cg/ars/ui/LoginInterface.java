package com.cg.ars.ui;

import java.util.Scanner;

import com.cg.ars.beans.UsersBean;
import com.cg.ars.consoles.AdminConsole;
import com.cg.ars.consoles.ExecutiveConsole;
import com.cg.ars.consoles.UserConsole;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.services.AdminService;
import com.cg.ars.services.AdminServiceImpl;


public class LoginInterface {

	public static void main(String[] args) {
		try{
			//creating executive service object

			AdminService adminService = new AdminServiceImpl();
			
			Scanner kbdInput = new Scanner(System.in);
			
			//declare all variables globally here
			int choice = 0;
			String userName = null;
			String password = null;
			int roleInt = 0;
			String role = null;
			UsersBean usersBean = null;
			boolean isValidUser = false;
			
			do{
				System.out.println("Welcome to Airline Reservation System.");
				System.out.println("Menu...");
				System.out.println("1. Login.");
				System.out.println("2. Exit.");
				
				System.out.println("Enter a choice");
				choice = kbdInput.nextInt();
				
				
				
				switch(choice){
				
				case 1: {
					//Login
					
					do{
					System.out.println("Enter your username.");
					userName = kbdInput.next();
					
					System.out.println("Enter your password.");
					password = kbdInput.next();
					
					//do pattern matching for role... all alphabets lowercase
					do{
						System.out.println("Enter your role.");
						System.out.println("1. customer");
						System.out.println("2. executive");
						System.out.println("3. admin");
						
						roleInt = kbdInput.nextInt();
						
						if(roleInt == 1){
							role = "customer";
						} else if(roleInt == 2){
							role = "executive";
						} else if(roleInt == 3){
							role = "admin";
						} else{
							System.out.println("Enter a role in {1,2,3}");
						}
					} while(roleInt!=1 && roleInt!=2 && roleInt!=3);
					
					
					usersBean = new UsersBean(userName, password, role);
					//validate from database
					isValidUser = adminService.validateUser(usersBean);
					if(!isValidUser){
						System.out.println("Enter correct login credentials.");
					}
					
					} while(!isValidUser);
					
					//role specific console allocation
					switch(roleInt){
					
					case 1:
					{
						UserConsole.getUserConsole();
						break;
					}// End of case 1, switch 2
					
					case 2:
					{
						ExecutiveConsole.getExecutiveConsole();
						break;
					}// End of case 2, switch 2
					
					case 3:
					{
						AdminConsole.getAdminConsole();
						break;
					}// End of case 3, switch 2
					
			
					}//end od switch 2
					
					break;
					
				}// End of case 1, switch 1
				case 2: {
					
					System.out.println("Thanks for using this application");
					break;
					
				}// End of case 2, switch 1
				
				
				
				}// End of switch 1
				
			}// End of do
			while(choice != 2);
		
		}// End of try block
		catch (AirlineException e) {
			e.printStackTrace();
	}//End of catch block

	}// End of main

}// End of class
