package com.cg.ars.services;

import java.time.LocalDate;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.beans.UsersBean;
import com.cg.ars.exceptions.AirlineException;

public interface AdminService {

	public boolean validateCity(String city) throws AirlineException;
	
	//UsersDao
	public boolean validateUser(UsersBean usersBean) throws AirlineException;
	
	//FlightInfoDao
	public boolean createNewFlight(FlightInfoBean flightBean) throws AirlineException;
	
	//flightInfoDao
	public FlightInfoBean viewFlightDetailsOnId(int flightNo) 
										throws AirlineException;
	
	//FlightInfoDao
	public boolean isFlightNoUnique(int flightNo) throws AirlineException;
	
	//date pattern validation
	public boolean validateStrDate(String strDate) throws AirlineException;
	
	//FlightInfoDao
	public boolean removeFlight(int flightNo) throws AirlineException;
	
	//FlightInfoDao
	public boolean updateArrTime(int flightNo,String arrTime)
			throws AirlineException;
	
	//FlightInfoDao
	public boolean updateDepTime(int flightNo,String depTime)
			throws AirlineException;
	
	//FlightInfoDao
	public boolean updateArrDate(int flightNo,LocalDate arrDate)
			throws AirlineException;
	
	//FlightInfoDao
	public boolean updateDepDate(int flightNo,LocalDate depDate) 
			throws AirlineException;
	
	//FlightInfoDao
	public boolean updateFirstSeats(int flightNo,int firstSeats) 
			throws AirlineException;
	
	//FlightInfoDao
	public boolean updateBussSeats(int flightNo,int bussSeats) 
			throws AirlineException;
	
}
