package com.cg.ars.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.beans.UsersBean;
import com.cg.ars.daos.BookingInfoDao;
import com.cg.ars.daos.BookingInfoDaoImpl;
import com.cg.ars.daos.FlightInfoDao;
import com.cg.ars.daos.FlightInfoDaoImpl;
import com.cg.ars.daos.UsersDao;
import com.cg.ars.daos.UsersDaoImpl;
import com.cg.ars.exceptions.AirlineException;

public class AdminServiceImpl implements AdminService {

	//creating relevant dao reference instances
		private UsersDao usersDao;
		private FlightInfoDao flightInfoDao;
		private BookingInfoDao bookingInfoDao;
		static Logger myLogger = Logger.getLogger("myLogger");
		
		
		public AdminServiceImpl() throws AirlineException {
			
			myLogger.info("Services: Dao injected."); 
			usersDao = new UsersDaoImpl();
			flightInfoDao = new FlightInfoDaoImpl();
			bookingInfoDao = new BookingInfoDaoImpl();
		}
	
		//validate city
		@Override
		public boolean validateCity(String city) throws AirlineException {
			
			Pattern pt = Pattern.compile("[A-Z][a-z]*");
			Matcher match = pt.matcher(city);
			boolean patternMatch =  match.matches();
			
			return patternMatch;
		}
	
		
	//validate User...usersDao
	//remove the comment
	 @Override
	public boolean validateUser(UsersBean usersBean) throws AirlineException {
		
		ArrayList<String> userNameList = usersDao.getUserNameList();
		boolean isExisting = false;
		if(userNameList.contains(usersBean.getUserName())){
			ArrayList<UsersBean> usersList = usersDao.getUsersList();
			UsersBean user1 = new UsersBean();
			for(UsersBean user : usersList){
				if(user.getUserName().equals(usersBean.getUserName())){
					user1 = user;
				}
					
			}
			if(user1.getPassword().equals(usersBean.getPassword()) && user1.getRole().equals(usersBean.getRole())){
				isExisting = true;
			}else{
				isExisting = false;
			}
		}
		return isExisting;
	}
	
	//duplicate
	/*@Override
	public boolean validateUser(UsersBean usersBean) throws AirlineException {
		
		ArrayList<UsersBean> usersList = usersDao.getUsersList();
		UsersBean user1 = new UsersBean();
		boolean isExisting = false;
		for(UsersBean user : usersList){
			if(user.getUserName().equals(usersBean.getUserName())){
				user1 = user;
			}
				
		}
		if(user1.getPassword().equals(usersBean.getPassword()) && user1.getRole().equals(usersBean.getRole())){
			isExisting = true;
		}else{
			isExisting = false;
		}
		
		return isExisting;

		
	}*/

	//create new flight...FlightInfoDao
	@Override
	public boolean createNewFlight(FlightInfoBean flightBean)
			throws AirlineException {
		
		boolean isCreated = flightInfoDao.createNewFlight(flightBean);
		
		return isCreated;
	}

	//check whether a flight with the given flightNo exists or not...FlightInfoDao
	@Override
	public boolean isFlightNoUnique(int flightNo) throws AirlineException {
		
		FlightInfoBean flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
		
		boolean isFlightNoUnique = false;
		if(flightBean != null)
		{
			 isFlightNoUnique = false;
		}
		else if(flightBean == null)
		{
			isFlightNoUnique = true;
		}
		return isFlightNoUnique;
	}
	
	//date pattern validation
	@Override
	public boolean validateStrDate(String strDate) throws AirlineException {
		
		try {
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(strDate, format);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	//view flight on Id...FlightInfoDao
	@Override
	public FlightInfoBean viewFlightDetailsOnId(int flightNo)
			throws AirlineException {
		
		FlightInfoBean flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
		
		return flightBean;
	}
	
	
	
	//remove Flight...FlightInfoDao
	@Override
	public boolean removeFlight(int flightNo) throws AirlineException {
		
		boolean isRemoved = flightInfoDao.removeFlight(flightNo);
		
		return isRemoved;
	}

	//updateArrTime...FlightInfoDao
	@Override
	public boolean updateArrTime(int flightNo, String arrTime)
			throws AirlineException {
		
		boolean isUpdated = flightInfoDao.updateArrTime(flightNo, arrTime);
		
		return isUpdated;
	}

	//updateDepTime...FlightInfoDao
	@Override
	public boolean updateDepTime(int flightNo, String depTime)
			throws AirlineException {
		
		boolean isUpdated = flightInfoDao.updateDepTime(flightNo, depTime);
		
		return isUpdated;
	}

	//updateArrDate...FlightInfoDao
	@Override
	public boolean updateArrDate(int flightNo, LocalDate arrDate)
			throws AirlineException {
		
		boolean isUpdated = flightInfoDao.updateArrDate(flightNo, arrDate);
		
		return isUpdated;
	}

	//updateDepDate...FlightInfoDao
	@Override
	public boolean updateDepDate(int flightNo, LocalDate depDate)
			throws AirlineException {
		
		boolean isUpdated = flightInfoDao.updateDepDate(flightNo, depDate);
				
		return isUpdated;
	}

	//updateFirstSeats...FlightInfoDao
	@Override
	public boolean updateFirstSeats(int flightNo, int firstSeats)
			throws AirlineException {
		
		boolean isUpdated = flightInfoDao.updateFirstSeats(flightNo, firstSeats);
		
		return isUpdated;
	}

	//updateBussSeats...FlightInfoDao
	@Override
	public boolean updateBussSeats(int flightNo, int bussSeats)
			throws AirlineException {
		
		boolean isUpdated = flightInfoDao.updateBussSeats(flightNo, bussSeats);
		
		return isUpdated;
	}

	

	

}
