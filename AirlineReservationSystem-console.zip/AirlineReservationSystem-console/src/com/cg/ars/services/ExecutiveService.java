package com.cg.ars.services;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.beans.UsersBean;
import com.cg.ars.exceptions.AirlineException;

public interface ExecutiveService {

	//usersDao
	public boolean validateUser(UsersBean usersBean) throws AirlineException;
	
	//flightInfoDao
	public FlightInfoBean viewFlightOccupancyOnId(int flightNo) 
									throws AirlineException;
	
	//FlightInfoDao
	public boolean validateFlightNo(int flightNo) throws AirlineException;
	
	//date pattern validation
	public boolean validateStrDate(String strDate) throws AirlineException;
	
	//FlightInfoDao
	public boolean validateDepDate(LocalDate depDate) throws AirlineException;
	
	//flightInfodao
	public ArrayList<FlightInfoBean> viewFlightOccupancyOnDate(LocalDate startDepDate, LocalDate endDepDate) 
									throws AirlineException;
	
	
}
