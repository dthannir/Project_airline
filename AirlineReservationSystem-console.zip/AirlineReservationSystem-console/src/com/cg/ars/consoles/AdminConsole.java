package com.cg.ars.consoles;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.services.AdminService;
import com.cg.ars.services.AdminServiceImpl;
import com.cg.ars.services.UserService;
import com.cg.ars.services.UserServiceImpl;

public class AdminConsole {

	public static void getAdminConsole() {
		
		try{
			//creating executive service object
			AdminService adminService = new AdminServiceImpl();
			UserService userService = new UserServiceImpl();
			
			Scanner kbdInput = new Scanner(System.in);
			
			//declare all variables globally here
			int choice1 = 0;
			int choice2 = 0;
			int flightNo = 0;
			boolean isFlightNoUnique = false;
			String airline = null;
			String depCity = null;
			String arrCity = null;
			String strDate = null;
			boolean strDateValid = false;
			LocalDate arrDate = null;
			LocalDate depDate = null;
			String strDepDate = null;
			String strArrDate = null;
			String depTime = null;
			String arrTime = null;
			int firstSeats = 0;
			int firstSeatsAvailable = 0;
			float firstSeatFare = 0;
			int bussSeats = 0;
			int bussSeatsAvailable = 0;
			float bussSeatFare = 0;
			DateTimeFormatter format = null;
			FlightInfoBean flightBean = null;
			boolean isCreated = false;
			boolean isRemoved = false;
			boolean isArrDateUpdated = false;
			boolean isDepDateUpdated = false;
			boolean isArrTimeUpdated = false;
			boolean isDepTimeUpdated = false;
			boolean isBussSeatsUpdated = false;
			boolean isFirstSeatsUpdated = false;
			boolean strCityValid = false;
		
			
			
			do{
				System.out.println("******************************************");
				System.out.println("Welcome to Airline Reservation System.");
				System.out.println("******************************************");
				System.out.println("Menu...");
				System.out.println("1. Create new flight.");
				System.out.println("2. Remove a flight.");
				System.out.println("3. Update flight details.");
				System.out.println("4. Log Out.");
				System.out.println("******************************************");
				
				do{
					System.out.println("Enter a choice");
					choice1 = kbdInput.nextInt();
					if(choice1!=1 && choice1!=2 && choice1!=3 && choice1!=4){
						System.out.println("Enter valid choice");
					}
				}while(choice1!=1 && choice1!=2 && choice1!=3 && choice1!=4);
				
				switch(choice1){
				
				case 1: {
					//Create new flight.
					do{
					System.out.println("Enter flight number.");
					flightNo = kbdInput.nextInt();
					isFlightNoUnique = adminService.isFlightNoUnique(flightNo);
					if(isFlightNoUnique != true){
						System.out.println("Flight No. already exists. Enter a different flight No.");
					}
					}while(!isFlightNoUnique);
					
					System.out.println("Enter Airline.");
					airline = kbdInput.next();
					
					do{
						System.out.println("Enter departure City.");
						depCity = kbdInput.next();
						strCityValid = adminService.validateCity(depCity);
						if(strCityValid == false){
							System.out.println("Enter city in format Mumbai");
						}
					} while(!strCityValid);
					
					
					
					do{
						System.out.println("Enter arrival City.");
						arrCity = kbdInput.next();
						strCityValid = adminService.validateCity(arrCity);
						if(strCityValid == false){
							System.out.println("Enter city in format Mumbai");
						}
					} while(!strCityValid);
					
					
					do{
					System.out.println("Enter departure date (yyyy-mm-dd).");
					strDate = kbdInput.next();
					strDateValid = adminService.validateStrDate(strDate);
					} while(!strDateValid);
					format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					depDate = LocalDate.parse(strDate, format);
					
					System.out.println("Enter arrival date (yyyy-mm-dd).");
					do{
					strDate = kbdInput.next();
					strDateValid = adminService.validateStrDate(strDate);
					} while(!strDateValid);
					format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					arrDate = LocalDate.parse(strDate, format);
					
					System.out.println("Enter departure time (in 24 hrs format HH:MM).");
			 		depTime = kbdInput.next();
			
			 		System.out.println("Enter arrival time (in 24 hrs format HH:MM).");
					arrTime = kbdInput.next();
					 
					System.out.println("Enter first class capacity");
					firstSeats = kbdInput.nextInt();
					firstSeatsAvailable = firstSeats; 
					
					System.out.println("Enter first class seat fare.");
					firstSeatFare = kbdInput.nextFloat();
				
					System.out.println("Enter business class capacity");
					bussSeats = kbdInput.nextInt();
					bussSeatsAvailable = bussSeats;
					
					System.out.println("Enter business class seat fare.");
					bussSeatFare = kbdInput.nextFloat();
					
					flightBean = new FlightInfoBean(flightNo, airline, depCity, arrCity,
													depDate, arrDate, depTime, arrTime, 
													firstSeats, firstSeatFare, firstSeatsAvailable, 
													bussSeats, bussSeatFare, bussSeatsAvailable);
					
					isCreated = adminService.createNewFlight(flightBean);
					if(isCreated)
					{
						System.out.println("A flight has been successfully added.");
						System.out.println("Flight details are: ");
						System.out.println("******************************************");
						System.out.println("Flight No. : " + flightBean.getFlightNo());
						System.out.println("Airline : " + flightBean.getAirline());
						System.out.println("Departure City : " + flightBean.getDepCity());
						System.out.println("Arrival City : " + flightBean.getArrCity());
						System.out.println("Departure Date : " + flightBean.getDepDate());
						System.out.println("Arrival Date : " + flightBean.getArrDate());
						System.out.println("Departure Time : " + flightBean.getDepTime());
						System.out.println("Arrival Time : " + flightBean.getArrTime());
						System.out.println("First Class Seats : " + flightBean.getFirstSeats());
						System.out.println("First Class Fare : " + flightBean.getFirstSeatFare());
						System.out.println("Business Class Seats : " + flightBean.getBussSeats());
						System.out.println("Business Class Fare : " + flightBean.getBussSeatFare());
						System.out.println("******************************************");
					}
					else
					{
						System.out.println("There was a problem in adding the flight.");
						System.out.println("Sorry for Inconvinience.");
					}
					
					
					
					break;
					}// End of case 1, switch 1
				case 2: {
					//Remove a flight
					
					do{
						System.out.println("Enter flight number which you want to remove.");
						flightNo = kbdInput.nextInt();
						isFlightNoUnique = adminService.isFlightNoUnique(flightNo);
						if(isFlightNoUnique == true){
							System.out.println("Flight No. does not exists. Enter a different flight No.");
						}
						}while(isFlightNoUnique);
						
					isRemoved = adminService.removeFlight(flightNo);
					
					if(isRemoved){
						System.out.println("Flight No. " + flightNo + " successfully removed.");
					} else{
						System.out.println("Problem in removing flight.");
					}
					
					
					break;
					}// End of case 2, switch 1
				case 3: {
					
					//updating the arrival date of a flight
						
						do{
							System.out.println("Enter flight number for which you want to update the details....");
							flightNo = kbdInput.nextInt();
							isFlightNoUnique = adminService.isFlightNoUnique(flightNo);
							if(isFlightNoUnique == true){
								System.out.println("Flight No. does not exists. Enter a different flight No.");
							}
							}while(isFlightNoUnique);
					
	
							
							
							do{
								System.out.println("Update any of the following details of the flight ");
								
								System.out.println("1. Arrival Date .");
								System.out.println("2. Departure Date.");
								System.out.println("3. Arrival Time");
								System.out.println("4. Departure Time.");
								System.out.println("5. First Class Seats");
								System.out.println("6. Business Class Seats");
								System.out.println("7. Go back");
								
								
								do{
									System.out.println("Enter a choice");
									choice2 = kbdInput.nextInt();
									if(choice2!=1 && choice2!=2 && choice2!=3 && choice2!=4 && choice2!=5 && choice2!=6 && choice2!=7){
										System.out.println("Enter valid choice");
									}
								}while(choice2!=1 && choice2!=2 && choice2!=3 && choice2!=4 && choice2!=5 && choice2!=6 && choice2!=7);
								
								
								switch(choice2){
					
								case 1: {
									
					
								do{	
										System.out.println("Enter the arrival Date to be updated(yyyy-mm-dd).");
										strArrDate = kbdInput.next();
										strDateValid = userService.validateStrDate(strArrDate);
										if(strDateValid == false){
											System.out.println("Enter date in format yyyy-mm-dd");
										}
								} while(!strDateValid);
								
								
									format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
									arrDate = LocalDate.parse(strArrDate, format);
								
									isArrDateUpdated = adminService.updateArrDate(flightNo, arrDate);
									if(isArrDateUpdated){
										System.out.println("Arrival Date " + arrDate + " is updated for the flight, " + flightNo );
									
									}
									else{
										System.out.println("Problem in updating the arrival date details.");
									
									}
									
								
									
									break;
								}// End of case 1
								
								

								case 2: {
									
					
								do{	
										System.out.println("Enter the Departure Date to be updated(yyyy-mm-dd).");
										strDepDate = kbdInput.next();
										strDateValid = userService.validateStrDate(strDepDate);
										if(strDateValid == false){
											System.out.println("Enter date in format yyyy-mm-dd");
										}
								} while(!strDateValid);
								
								
									format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
									depDate = LocalDate.parse(strDepDate, format);
									
									isDepDateUpdated = adminService.updateDepDate(flightNo, depDate);
									if(isDepDateUpdated){
										System.out.println("Departure Date " + depDate + " is updated for the flight, " + flightNo );
									}
									else{
										System.out.println("Problem in updating the departure date details.");
									}
									
									System.out.println();
									
									break;
								}// End of case 2
								
								
								case 3: {
									
										System.out.println("Enter the Arrival Time to be updated(HH:MM).");
											arrTime = kbdInput.next();
											isArrTimeUpdated = adminService.updateArrTime(flightNo, arrTime);
											
											if(isArrTimeUpdated){
												System.out.println("Arrival Time " + arrTime + " is updated for the flight, " + flightNo );
											}
												else{
												System.out.println("Problem in updating the arrival time details.");
											}
										
											System.out.println();
											
											break;
											
									}// End of case 3
								
								
								
								case 4: {
									
									System.out.println("Enter the Departure Time to be updated(HH:MM).");
										depTime = kbdInput.next();
										isDepTimeUpdated = adminService.updateDepTime(flightNo, depTime);
										
										if(isDepTimeUpdated){
											System.out.println("Departure Time " + depTime + " is updated for the flight, " + flightNo );
										}
											else{
											System.out.println("Problem in updating the departure time details.");
										}
									
										System.out.println();
										
										break;
								}// End of case 4
								
									
								case 5: {
									
									System.out.println("Enter the no of First Class Seats  to be updated.");
										firstSeats = kbdInput.nextInt();
										isFirstSeatsUpdated = adminService.updateFirstSeats(flightNo, firstSeats);
										
										if(	isFirstSeatsUpdated ){
											System.out.println("First Class Seats is updated for the flight, " + flightNo + " updated to " + firstSeats );
										}
											else{
											System.out.println("Problem in updating the First Class details.");
										}
										
										System.out.println();
										
										break;
								}// End of case 5
								
								
								case 6: {
									
									System.out.println("Enter the no of Business Class Seats  to be updated.");
										bussSeats = kbdInput.nextInt();
										isBussSeatsUpdated = adminService.updateBussSeats(flightNo, bussSeats)	;								
										
										if(	isBussSeatsUpdated ){
											System.out.println("First Class Seats is updated for the flight, " + flightNo + " updated to " + bussSeats );
										}
											else{
											System.out.println("Problem in updating the Business Class details.");
										}
										
										System.out.println();
										
										break;
								}// End of case 6
								
								case 7: {
									
										
										break;
								}// End of case 6
							}//end of switch
							}while(choice2!=7);
							
				
					break;	
			
					}// End of case 3, switch 1
				
				case 4: {
					
					System.out.println("Logged Out successfully.");
					System.out.println("Thanks and visit again.");
					
					break;
					}// End of case 4, switch 1
				
				
				}//End of switch 1
				
				
			}// End of do
			while(choice1 != 4);
		
		}// End of try block
		catch (AirlineException e) {
			e.printStackTrace();
	}//End of catch block

	}// End of main

}// End of class
