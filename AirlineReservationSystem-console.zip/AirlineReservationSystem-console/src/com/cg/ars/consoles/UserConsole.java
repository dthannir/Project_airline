package com.cg.ars.consoles;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ars.beans.BookingInfoBean;
import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.services.UserService;
import com.cg.ars.services.UserServiceImpl;

public class UserConsole {

	public static void getUserConsole(){
		
		try {
		//creating user service object
		UserService userService = new UserServiceImpl();
		
		//BookingInfoBean object
		BookingInfoBean bookingInfoBean = new BookingInfoBean();

		Scanner kbdInput = new Scanner(System.in);
		
		//declare all variables globally here
		int choice = 0;
		String depCity = null;
		String arrCity = null;
		String strDate = null;
		boolean strDateValid = false;
		DateTimeFormatter format = null;
		LocalDate depDate = null;
		ArrayList<FlightInfoBean> flightInfoBeanList = null;
		int flightNo = 0;
		String classType = null;
		int noOfPassengers = 0;
		float totalFare = 0.0f;
		String creditCardInfo = null;
		String custEmail = null;
		boolean flightNoValid = false;
		boolean noOfPassengersValid = false;
		boolean custEmailValid = false;
		boolean creditCardInfoValid = false;
		int bookingId = 0;
		boolean bookingIdValid = false;
		boolean isBookingCancelled = false;
		boolean strCityValid = false;
		
		
		
				do {   
					System.out.println("******************************************");
					System.out.println("Welcome to Airline Reservation System.");
					System.out.println("******************************************");
					System.out.println("Menu...");
					System.out.println("1. Book a flight.");
					System.out.println("2. View booking details.");
					/*System.out.println("3. Update booking details.");*/
					System.out.println("3. Cancel booking.");
					System.out.println("4. Log Out.");
					System.out.println("******************************************");
					
					do{
						System.out.println("Enter a choice");
						choice = kbdInput.nextInt();
						if(choice!=1 && choice!=2 && choice!=3 && choice!=4){
							System.out.println("Enter valid choice");
						}
					}while(choice!=1 && choice!=2 && choice!=3 && choice!=4);
					
					switch(choice){
					
					case 1: {
						//1. Book a flight
						//Enter valid depCity arrCity and depDate 
					
						do{
							System.out.println("Enter source city.");
							depCity = kbdInput.next();
							strCityValid = userService.validateCity(depCity);
							if(strCityValid == false){
								System.out.println("Enter city in format Mumbai");
							}
						} while(!strCityValid);
						
					
					
						do{
							System.out.println("Enter arrival city.");
							arrCity = kbdInput.next();
							strCityValid = userService.validateCity(arrCity);
							if(strCityValid == false){
								System.out.println("Enter city in format Mumbai");
							}
						} while(!strCityValid);
						
					
					
						do{
							System.out.println("Enter the date of departure(yyyy-mm-dd).");
							strDate = kbdInput.next();
							strDateValid = userService.validateStrDate(strDate);
							if(strDateValid == false){
								System.out.println("Enter date in format yyyy-mm-dd");
							}
						} while(!strDateValid);
						
						format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						depDate = LocalDate.parse(strDate, format);
						
						
					// Retrieve flight details
					
					flightInfoBeanList = userService.viewFlightList(depCity, arrCity, depDate);
					for(FlightInfoBean flightInfo : flightInfoBeanList){
						System.out.println("******************************************");
						System.out.println("Flight No : " + flightInfo.getFlightNo());
						System.out.println("Airline : " + flightInfo.getAirline());
						System.out.println("Departure City : " + flightInfo.getDepCity());
						System.out.println("Arrival City : " + flightInfo.getArrCity());
						System.out.println("Departure Date : " + flightInfo.getDepDate());
						System.out.println("Arrival Date : " + flightInfo.getArrDate());
						System.out.println("Departure Time : " + flightInfo.getDepTime());
						System.out.println("Arrival Time : " + flightInfo.getArrTime());
						System.out.println("First Class Seats Fare : " + flightInfo.getFirstSeatFare());
						System.out.println("Bussiness Class Seats Fare : " + flightInfo.getBussSeatFare());
						System.out.println("******************************************");
					}
					if(flightInfoBeanList.isEmpty()){
						System.out.println("Sorry!!! No flights found for the given details.");
						break;
					}
					
					System.out.println("Do you wish to book a flight?");
					System.out.println("1. Yes.");
					System.out.println("2. No.");
					
					do{
						System.out.println("Enter a choice");
						choice = kbdInput.nextInt();
						if(choice!=1 && choice!=2){
							System.out.println("Enter valid choice");
						}
					}while(choice!=1 && choice!=2);
					
					switch(choice){
					
						case 1: {
							//I wish to book a flight.
							do{
							System.out.println("Enter flight number.");
							flightNo = kbdInput.nextInt();
							flightNoValid = userService.validateFlightNo(flightNo);
							} while(!flightNoValid);
							
							do{
							System.out.println("Select class type.");
							System.out.println("1. First Class.");
							System.out.println("2. Business Class.");
							System.out.println("Enter a choice");
							choice = kbdInput.nextInt();
							if(choice==1){
								classType = "FIRST";
							}else if(choice==2){
								classType = "BUSINESS";
							}
							} while(choice!=1 && choice!=2);
							
							do{
							System.out.println("Enter number of passengers.");
							noOfPassengers = kbdInput.nextInt();
							noOfPassengersValid = userService.validateNoOfPassengers(flightNo, classType, noOfPassengers);
							} while(!noOfPassengersValid);
							
							totalFare = userService.generateTotalFare(flightNo, classType, noOfPassengers);
							System.out.println("Your total fare is: "+ totalFare);
							
							System.out.println("Do you wish to continue?");
							System.out.println("1. Yes.");
							System.out.println("2. No.");
							
							do{
								System.out.println("Enter a choice");
								choice = kbdInput.nextInt();
								if(choice!=1 && choice!=2){
									System.out.println("Enter valid choice");
								}
							}while(choice!=1 && choice!=2);
							
							switch(choice){
							
								case 1: {
									//I wish to continue and pay the fare.
									do{
									System.out.println("Enter your email.");
									custEmail = kbdInput.next();
									custEmailValid = userService.validateCustEmail(custEmail);
									} while(!custEmailValid);
									
									do{
									System.out.println("Enter your credit card number");
									creditCardInfo = kbdInput.next();
									creditCardInfoValid = userService.validateCreditCardInfo(creditCardInfo);
									} while(!creditCardInfoValid);
									
									
									bookingInfoBean.setFlightNo(flightNo);
									bookingInfoBean.setCustEmail(custEmail);
									bookingInfoBean.setNoOfPassengers(noOfPassengers);
									bookingInfoBean.setClassType(classType);
									bookingInfoBean.setTotalFare(totalFare);
									bookingInfoBean.setCreditCardInfo(creditCardInfo);
									bookingInfoBean.setSrcCity(depCity);
									bookingInfoBean.setDestCity(arrCity);
									
									
									bookingId = userService.bookFlight(flightNo, bookingInfoBean);
									System.out.println("Thank You for booking with Airline Resevation System.");
									System.out.println("Your booking Id is: " + bookingId);
									System.out.println("We hope to see you again.");
									
									break;
								}// End of case 1, switch 3
								
								case 2: {
									//I do not wish to pay the fare.
									
									System.out.println("Thanks and visit again.");
									
									break;
								}// End of case 2, switch 3
							
							}// End of switch 3
						
							break;	
							}// End of case 1, switch 2
							
							case 2: {
								//I do not wish to book a flight.
								
								System.out.println("Thanks and visit again.");
								
								break;
							}// End of case 2, switch 2
						
						
						}// End of switch 2
						
						
							break;
						}// End of case 1, switch 1
     
						
						case 2: {
							//2. View booking details.
							
							do{
							System.out.println("Enter your booking Id.");
							bookingId = kbdInput.nextInt();
							bookingIdValid = userService.validateBookingId(bookingId);
							} while(!bookingIdValid);
							
							bookingInfoBean = userService.viewBookingOnId(bookingId);
							System.out.println("******************************************");
							System.out.println("Your booking details are: \n");
							System.out.println("Booking Id : " + bookingInfoBean.getBookingId());
							System.out.println("Flight No : " + bookingInfoBean.getFlightNo());
							System.out.println("Email : " + bookingInfoBean.getCustEmail());
							System.out.println("No. of seats : " + bookingInfoBean.getNoOfPassengers());
							System.out.println("Class : " + bookingInfoBean.getClassType());
							System.out.println("Total Fare : " + bookingInfoBean.getTotalFare());
							System.out.println("Departure City : " + bookingInfoBean.getSrcCity());
							System.out.println("Arrival City : " + bookingInfoBean.getDestCity());
							System.out.println("******************************************");
							
							
							break;
						}// End of case 2, switch 1
						
						
						/*case 3: {
							//3. Update booking details.
							 
							do{
								System.out.println("Enter your booking Id.");
								bookingId = kbdInput.nextInt();
								bookingIdValid = userService.validateBookingId(bookingId);
								} while(!bookingIdValid);
							 
							isBookingUpdated = userService.updateBookingOnId(bookingId);
							if(isBookingUpdated){
								System.out.println("Your details have been successfully updated.");
								
								bookingInfoBean = userService.viewBookingOnId(bookingId);
								System.out.println("Your updated booking details are: \n");
								System.out.println(bookingInfoBean);
							}else{
								System.out.println("There was a problem in updating your booking details.");
								System.out.println("Sorry for inconvinience.");
							}
							
							break;
						}// End of case 3, switch 1   
					*/	
	
						
						
						case 3: {
							//3. Cancel booking.
							
							
							System.out.println("Enter your booking Id.");
							bookingId = kbdInput.nextInt();
							bookingIdValid = userService.validateBookingId(bookingId);
							
							if(!bookingIdValid){
								System.out.println("You have entered a wrong booking Id");
								break;
							}
							
							isBookingCancelled = userService.cancelBookingOnId(bookingId);
							if(isBookingCancelled){
								System.out.println("Your booking has been successfully cancelled.");								
							}else{
								System.out.println("There was a problem in cancelling your booking.");
								System.out.println("Sorry for inconvinience.");
							}
							
							break;
						}// End of case 3, switch 1
						
						case 4: {
							//4. Exit.
						
							System.out.println("Logged Out successfully.");
							System.out.println("Thanks and visit again.");
							  
							break;
						}// End of case 4, switch 1
						
						
						}// End of switch 1
				
					
					}// End of do
			 			while(choice != 4);
				
				}//end of Try Block
					catch (AirlineException e) {
						e.printStackTrace();
			}//End of catch block

	}// End of main

}// End of class
