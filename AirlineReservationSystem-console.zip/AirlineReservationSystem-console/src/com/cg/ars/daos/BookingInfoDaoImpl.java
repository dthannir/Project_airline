package com.cg.ars.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




import org.apache.log4j.Logger;

import com.cg.ars.beans.BookingInfoBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.util.ConnectionUtil;

public class BookingInfoDaoImpl implements BookingInfoDao {

private Connection connect = null;
static Logger myLogger = Logger.getLogger("myLogger");

	
	public BookingInfoDaoImpl() throws AirlineException {
		
		ConnectionUtil conn = new ConnectionUtil();
		connect = conn.getConnection();
		myLogger.info("Connection procured in BookingInfoDaoImpl().");	//logger message
	}

	
	//create new booking...userService
	@Override
	public int createNewBooking(BookingInfoBean bookingInfoBean)
			throws AirlineException {
		
		myLogger.info("Execution in createNewBooking()."); //logger message
		  
		String sequenceQry = "select autoBookingId.nextval from DUAL";
		
		int recsAffected = 0;
        int bookingId = 0;
		
		try(PreparedStatement stmt = connect.prepareStatement(sequenceQry);
				ResultSet rs = stmt.executeQuery();	)
				{
				myLogger.info("Query execution: "+ sequenceQry); //logger message
				 while(rs.next()){
				 bookingId = rs.getInt(1);
				}
		
			} catch (SQLException e) {
				 myLogger.error("Exception from createNewBooking() while generating booking ID", e);
				throw new AirlineException("Problem in generating booking Id", e);
			}
		
		String qry = "insert into bookingInfo values(?,?,?,?,?,?,?,?,?)";
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			){
				
				stmt.setInt(1, bookingId);
				stmt.setInt(2, bookingInfoBean.getFlightNo());
				stmt.setString(3, bookingInfoBean.getCustEmail());
				stmt.setInt(4, bookingInfoBean.getNoOfPassengers());
				stmt.setString(5, bookingInfoBean.getClassType());
				stmt.setFloat(6, bookingInfoBean.getTotalFare());
				stmt.setString(7, bookingInfoBean.getCreditCardInfo());
				stmt.setString(8, bookingInfoBean.getSrcCity());
				stmt.setString(9, bookingInfoBean.getDestCity());
				
				recsAffected = stmt.executeUpdate();
				
			
		} catch (SQLException e) {
			 myLogger.error("Exception from createNewBooking()", e);
			throw new AirlineException("Problem in createNewBooking(BookingInfoBean bookingInfoBean)",e);
		}
			return bookingId;
	}

	
	//get Booking On Id...userService
	@Override
	public BookingInfoBean getBookingOnId(int bookingId)
			throws AirlineException {
		
		BookingInfoBean bookingInfoBean =null;
		ResultSet rs = null;
		
	    myLogger.info("Execution in getBookingOnId()"); //logger message
		String qry="SELECT * FROM bookingInfo WHERE bookingId=?";
		
		try(
			PreparedStatement stmt = connect.prepareStatement(qry);
			){
			
				myLogger.info("Query execution: "+ qry); //logger message
				
				stmt.setInt(1, bookingId);
				rs = stmt.executeQuery();
				
				
				while(rs.next()){
				
				int flightNo = rs.getInt("flightNo");
				String custEmail = rs.getString("custEmail");
				int noOfPassengers = rs.getInt("noOfPassengers");
				String classType = rs.getString("classType");
				float totalFare = rs.getFloat("totalFare");
				String creditCardInfo = rs.getString("creditCardInfo");
				String srcCity = rs.getString("srcCity");
				String destCity = rs.getString("destCity");
				
				bookingInfoBean = new BookingInfoBean(bookingId, flightNo, custEmail, noOfPassengers, classType, totalFare, creditCardInfo, srcCity, destCity);
				}
			}
			catch (SQLException e) {
				throw new AirlineException("Problem in getBookingOnId()",e);
		} 
			finally {
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					
					myLogger.error("Exception from getBookingOnId()", e); //logger message
						
					throw new AirlineException("Problem in closing Result Set", e);
				}
			}
		}
		return bookingInfoBean;
	}

	//remove booking on id...userService
	@Override
	public boolean removeBookingOnId(int bookingId) throws AirlineException {
		
		 myLogger.info("Execution in removeBookingOnId()"); //logger message
		String qry = "delete from bookingInfo where bookingId=?";
		int recAffected = 0;
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			){
			
			myLogger.info("Query execution: "+ qry); //logger message
			
			stmt.setInt(1, bookingId);
			recAffected = stmt.executeUpdate();
			}
		      catch(Exception e){

					myLogger.error("Exception from removeBookingOnId()", e); //logger message
						
					throw new AirlineException("Problem in removeBookingOnId()", e);
			}

		return recAffected>0?true:false;
	}
	
	
}
