package com.cg.ars.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;



import org.apache.log4j.Logger;

import com.cg.ars.beans.UsersBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.util.ConnectionUtil;

public class UsersDaoImpl implements UsersDao {

private Connection connect = null;

static Logger myLogger = Logger.getLogger("myLogger");	

	public UsersDaoImpl() throws AirlineException {
		
		ConnectionUtil conn = new ConnectionUtil();
		connect = conn.getConnection();
		myLogger.info("Connection procured in UsersDaoImpl().");
	}

	// get userName list
	@Override
	public ArrayList<String> getUserNameList() throws AirlineException {
		
		myLogger.info("Execution in getUserNameList()."); //logger message
		
		ArrayList<String> userNameList = new ArrayList<>();
		
		String qry = "select userName from USERS";
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
				ResultSet rs = stmt.executeQuery();
			){
			
				myLogger.info("Query execution: "+ qry); //logger message
				while(rs.next()){
				String userName = rs.getString(1);
				
				userNameList.add(userName);
				}
				} catch (SQLException e) {
					myLogger.error("Exception from getUserNameList()", e); //logger message
					throw new AirlineException("Probelm in  getUserNameList()!!!",e);
				}
			return userNameList;
		
	}

	
	//get Users List...called by users validation method
	@Override
	public ArrayList<UsersBean> getUsersList() throws AirlineException {
		
		myLogger.info("Execution in getUsersList()."); //logger message
		
		UsersBean usersBean = null;
		ArrayList<UsersBean> usersList = new ArrayList<>();
		
		String qry = "select * from USERS";
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
				ResultSet rs = stmt.executeQuery();
			){
			
				myLogger.info("Query execution: "+ qry); //logger message
				
				while(rs.next()){
				String userName = rs.getString(1);
				String password = rs.getString(2);
				String role = rs.getString(3);
				
				usersBean = new UsersBean(userName, password, role);
				usersList.add(usersBean);
				}
				} catch (SQLException e) {
					myLogger.error("Exception from getUsersList()", e); //logger message
					throw new AirlineException("Probelm in  getUsersList()!!!",e);
				}
			return usersList;
		}

	
	
	
	
}
